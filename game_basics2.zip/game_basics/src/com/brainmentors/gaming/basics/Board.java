package com.brainmentors.gaming.basics;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.settings.GameConstants;
import com.brainmentors.gaming.sprites.Player;

// JPanel (Canvas)
public class Board extends JPanel implements GameConstants, ActionListener, KeyListener{
	BufferedImage backgroundImage;
	Player player;
	Timer timer;
	public Board() throws Exception {
		//setBackground(Color.BLACK);
		loadBackGround();
		player = new Player();
		setFocusable(true);
		bindEvents();
		gameLoop();
	}
	
	void bindEvents() {
		this.addKeyListener(this);
	}
	
	void gameLoop() {
		timer = new Timer(DELAY, this);
		timer.start();
	}
	
	void loadBackGround() throws Exception {
		backgroundImage = ImageIO.read(Board.class.getResource("bg.jpeg"));
	}
	
	// All Painting Stuff will be inside the paintComponent
	@Override
	protected void paintComponent(Graphics pen) {
		// TODO Auto-generated method stub
		super.paintComponent(pen);
		// Drawing Stuff
		pen.drawImage(backgroundImage,0,0,BOARD_WIDTH, BOARD_HEIGHT, null);
		player.draw(pen);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		repaint();
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_K) {
			player.setAction(KICK);
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}

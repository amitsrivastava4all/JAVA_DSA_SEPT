package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.settings.GameConstants;

public class Player implements GameConstants {
	private int x;
	private int y;
	private int w;
	private int h;
	private int action;
	final int TOTAL_MOVES = 6;
	BufferedImage fullImage;
	BufferedImage defaultMove [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage kick [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage currentMoves [] = new BufferedImage[TOTAL_MOVES];
	
	public Player() throws Exception {
		x = 50;
		h = w = 150;
		y = FLOOR - h;
		action = DEFAULT_MOVE;
		fullImage = ImageIO.read(Player.class.getResource(PLAYER_IMAGE));
		defaultAction();
		kickAction();
	
	
	}
	
	public void setAction(int action) {
		
		this.action = action;
	}
	
	private void kickAction() {
		int w = 70;
		kick[0] =  fullImage.getSubimage(40, 1044, w, 100);
		kick[1] =  fullImage.getSubimage(121, 1042, w, 100);
		kick[2] =  fullImage.getSubimage(203, 1038, w+50, 100);
		kick[3] =  fullImage.getSubimage(327, 1046, w, 100);
		kick[4] =  fullImage.getSubimage(410, 1045, w, 100);
		kick[5] =  fullImage.getSubimage(484, 1048, w+30, 100);
	}
	
	private  void defaultAction() {
		int w = 70;
		defaultMove[0] =  fullImage.getSubimage(65, 233, w, 100);
		defaultMove[1] =  fullImage.getSubimage(143, 235, w, 100);
		defaultMove[2] =  fullImage.getSubimage(226, 234, w, 100);
		defaultMove[3] =  fullImage.getSubimage(305, 234, w, 100);
		defaultMove[4] =  fullImage.getSubimage(378, 234, w, 100);
		defaultMove[5] =  fullImage.getSubimage(453, 240, w, 100);
	}
	int index = 0;
	
	private void printCurrentMove(Graphics g) {
		if(index>5) {
			index = 0;
			action = DEFAULT_MOVE;
		}
		g.drawImage(currentMoves[index],x,y,w,h,null);
		index++;
	}
	
	
	
	public void draw(Graphics g) {
		if(action == DEFAULT_MOVE) {
			currentMoves = defaultMove;
		}
		else if (action == KICK) {
			currentMoves = kick;
		}
		printCurrentMove(g);
	}

}

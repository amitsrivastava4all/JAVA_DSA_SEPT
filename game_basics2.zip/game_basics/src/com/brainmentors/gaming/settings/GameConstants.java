package com.brainmentors.gaming.settings;

public interface GameConstants {
	
	int BOARD_WIDTH = 1200; // public static final int BOARD_WIDTH=1200;
	int BOARD_HEIGHT = 900;
	int FLOOR = BOARD_HEIGHT - 150;
	String PLAYER_IMAGE = "player-sprite.gif";
	int DELAY = 100;
	int DEFAULT_MOVE = 1;
	int KICK = 2;
	int PUNCH = 3;
}

package com.brainmentors.gaming.sprites;

public class RyuPlayer extends Player {
	public RyuPlayer() throws Exception {
		super(PLAYER_IMAGE); 
		this.x = 50;
		
	}
	@Override
	protected void kickAction() {
		int w = 70;
		kick[0] =  fullImage.getSubimage(40, 1044, w, 100);
		kick[1] =  fullImage.getSubimage(121, 1042, w, 100);
		kick[2] =  fullImage.getSubimage(203, 1038, w+50, 100);
		kick[3] =  fullImage.getSubimage(327, 1046, w, 100);
		kick[4] =  fullImage.getSubimage(410, 1045, w, 100);
		kick[5] =  fullImage.getSubimage(484, 1048, w+30, 100);
	}
	@Override
	protected  void defaultAction() {
		int w = 70;
		defaultMove[0] =  fullImage.getSubimage(65, 233, w, 100);
		defaultMove[1] =  fullImage.getSubimage(143, 235, w, 100);
		defaultMove[2] =  fullImage.getSubimage(226, 234, w, 100);
		defaultMove[3] =  fullImage.getSubimage(305, 234, w, 100);
		defaultMove[4] =  fullImage.getSubimage(378, 234, w, 100);
		defaultMove[5] =  fullImage.getSubimage(453, 240, w, 100);
	}

}

package com.brainmentors.gaming.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

import com.brainmentors.gaming.settings.GameConstants;

public abstract class Player implements GameConstants {
	protected int x;
	protected int y;
	protected int w;
	protected int h;
	protected int speed;
	protected int action;
	protected boolean isJumping ;
	final int TOTAL_MOVES = 6;
	protected BufferedImage fullImage;
	BufferedImage defaultMove [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage kick [] = new BufferedImage[TOTAL_MOVES];
	BufferedImage currentMoves [] = new BufferedImage[TOTAL_MOVES];
	protected int currentForce;
	public Player(String imageName) throws Exception {
		isJumping = false;
		//x = 50;
		
		h = w = 300;
		y = FLOOR - h;
		speed = SPEED;
		action = DEFAULT_MOVE;
		fullImage = ImageIO.read(Player.class.getResource(imageName));
		defaultAction();
		kickAction();
	
	
	}
	protected abstract void defaultAction();
	protected abstract void kickAction();
	
	public void fall() {
		if(y>=FLOOR-h) {
			isJumping =false;
			return ;
		}
		currentForce = currentForce + GRAVITY;
		y = y + currentForce;
	}
	
	public void jump() {
		if(!isJumping) {
		currentForce = FORCE;
		y = y + FORCE;
		isJumping = true;
		}
	}
	
	
	public int getSpeed() {
		return speed;
	}


	public void setSpeed(int speed) {
		this.speed = speed;
	}


	public void move() {
		x = x + speed;
	}
	
	public void setAction(int action) {
		
		this.action = action;
	}
	
		int index = 0;
	
	protected void printCurrentMove(Graphics g) {
		if(index>5) {
			index = 0;
			action = DEFAULT_MOVE;
		}
		g.drawImage(currentMoves[index],x,y,w,h,null);
		index++;
	}
	
	
	
	public void draw(Graphics g) {
		if(action == DEFAULT_MOVE) {
			currentMoves = defaultMove;
		}
		else if (action == KICK) {
			currentMoves = kick;
		}
		printCurrentMove(g);
	}

}

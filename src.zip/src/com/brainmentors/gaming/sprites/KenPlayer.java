package com.brainmentors.gaming.sprites;

public class KenPlayer extends Player {
	public KenPlayer() throws Exception {
		super(KEN_IMAGE);
		x = BOARD_WIDTH - 400;
		
	}
	@Override
	protected void kickAction() {
		int w = 70;
		kick[0] =  fullImage.getSubimage(40, 1044, w, 100);
		kick[1] =  fullImage.getSubimage(121, 1042, w, 100);
		kick[2] =  fullImage.getSubimage(203, 1038, w+50, 100);
		kick[3] =  fullImage.getSubimage(327, 1046, w, 100);
		kick[4] =  fullImage.getSubimage(410, 1045, w, 100);
		kick[5] =  fullImage.getSubimage(484, 1048, w+30, 100);
	}
	@Override
	protected  void defaultAction() {
		int w = 60;
		int h = 90;
		//-2028px -868px;
		defaultMove[0] =  fullImage.getSubimage(2028, 863, w, h);
		defaultMove[1] =  fullImage.getSubimage(1963, 863, w, h);
		defaultMove[2] =  fullImage.getSubimage(1887, 863, w, h);
		defaultMove[3] =  fullImage.getSubimage(1815, 863, w, h);
		defaultMove[4] =  fullImage.getSubimage(1753, 863, w, h);
		defaultMove[5] =  fullImage.getSubimage(1685, 863, w, h);
	}

}

package com.brainmentors.gaming.settings;

public interface GameConstants {
	
	int BOARD_WIDTH = 1200; // public static final int BOARD_WIDTH=1200;
	int BOARD_HEIGHT = 900;
	int FLOOR = BOARD_HEIGHT - 150;
	String PLAYER_IMAGE = "player-sprite.gif";
	String KEN_IMAGE = "kenimage.png";
	int DELAY = 70;
	int DEFAULT_MOVE = 1;
	int KICK = 2;
	int HIT = 0;
	int PUNCH = 3;
	int SPEED = 10;
	int FORCE = -20;
	int GRAVITY = 1;
}

package com.brainmentors.gaming.basics;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
import javax.swing.Timer;

import com.brainmentors.gaming.settings.GameConstants;
import com.brainmentors.gaming.sprites.KenPlayer;
import com.brainmentors.gaming.sprites.KenPlayer;
import com.brainmentors.gaming.sprites.RyuPlayer;



// JPanel (Canvas)
public class Board extends JPanel implements GameConstants, ActionListener, KeyListener{
	BufferedImage backgroundImage;
	RyuPlayer  ryu;
	KenPlayer  ken;
	Timer timer;
	public Board() throws Exception {
		//setBackground(Color.BLACK);
		loadBackGround();
		ryu = new RyuPlayer(); // Ryu Position
		ken = new KenPlayer();
		setFocusable(true);
		bindEvents();
		gameLoop();
	}
	
	void bindEvents() {
		this.addKeyListener(this);
	}
	
	void gameLoop() {
		timer = new Timer(DELAY, this);
		timer.start();
	}
	
	void loadBackGround() throws Exception {
		backgroundImage = ImageIO.read(Board.class.getResource("bg.jpeg"));
	}
	
	// All Painting Stuff will be inside the paintComponent
	@Override
	protected void paintComponent(Graphics pen) {
		// TODO Auto-generated method stub
		super.paintComponent(pen);
		// Drawing Stuff
		pen.drawImage(backgroundImage,0,0,BOARD_WIDTH, BOARD_HEIGHT, null);
		ryu.draw(pen);
		ken.draw(pen);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ryu.fall();
		repaint();
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode()==KeyEvent.VK_K) {
			ryu.setAction(KICK);
		}
		else if (e.getKeyCode()== KeyEvent.VK_RIGHT) {
			ryu.setSpeed(SPEED);
			ryu.move();
		}
		else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			ryu.setSpeed(SPEED * -1);
			ryu.move();
		}
		else if(e.getKeyCode() == KeyEvent.VK_SPACE) {
			ryu.jump();
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}

package com.brainmentors.gaming.basics;

import javax.swing.JFrame;

public class GameFrame extends JFrame {
	public GameFrame() throws Exception {
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setSize(1200, 900);
		setLocationRelativeTo(null);
		setTitle("Game Basics");
		Board board = new Board();
		add(board);
		setVisible(true);
	}
	public static void main(String[] args) {
		try {
			GameFrame obj = new GameFrame();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}

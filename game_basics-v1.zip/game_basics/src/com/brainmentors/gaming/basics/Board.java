package com.brainmentors.gaming.basics;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

// JPanel (Canvas)
public class Board extends JPanel{
	BufferedImage backgroundImage;
	public Board() throws Exception {
		//setBackground(Color.BLACK);
		loadBackGround();
	}
	
	void loadBackGround() throws Exception {
		backgroundImage = ImageIO.read(Board.class.getResource("bg.jpeg"));
	}
	
	// All Painting Stuff will be inside the paintComponent
	@Override
	protected void paintComponent(Graphics pen) {
		// TODO Auto-generated method stub
		super.paintComponent(pen);
		// Drawing Stuff
		pen.drawImage(backgroundImage,0,0,1200, 900, null);
	}

}

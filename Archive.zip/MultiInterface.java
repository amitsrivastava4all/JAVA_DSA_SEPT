interface I{
    default void show(){
        System.out.println("I Show ");
    }
    void disp();
}
interface J{
    default void show(){
        System.out.println("J Show");
    }
    void disp();
}
interface K extends I, J{
    @Override
    // tell to the compiler and tell to the developer
    public default void show(){
        // super
        I.super.show();
        J.super.show();
        System.out.println("K Show...");
    }
}
class T implements K{

    @Override
    public void disp() {
        // TODO Auto-generated method stub
        
    }
    
}
public class MultiInterface {
    public static void main(String[] args) {
        T obj = new T();
        obj.show();
    }
}

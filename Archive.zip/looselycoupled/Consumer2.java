

public class Consumer2 {
    public static void main(String[] args) {
        ProducerInterface p = new Producer(); // Upcasting 
        p.callMe();
        //p.dontCallMe();
    }
}

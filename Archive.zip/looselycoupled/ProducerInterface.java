

public interface ProducerInterface {
    public void  callMe(); // Expose
}

interface X{
    void show(); // public abstract void show();
    void disp();
    // Java 8 onwards Interface default methods 
    public default void output(){
        System.out.println("X Output...");
    }
}
class Y implements X{

    @Override
    public void show() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void disp() {
        // TODO Auto-generated method stub
        
    }

}
// Partial Implementation
// abstract class Y implements X{
//     public void show(){
//         System.out.println("Y Show ");
//     }
// }
// // Partial Implementation
// class Z extends Y{
//     public void disp(){
//         System.out.println("Z Disp...");
//     }
// }
public class InterfaceFlexi {
    public static void main(String[] args) {
        
    }
}

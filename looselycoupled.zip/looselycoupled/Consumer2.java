

public class Consumer2 {
    public static void main(String[] args) {
        ProducerInterface p = Factory.getInstance();
        p.callMe();
        //p.dontCallMe();
    }
}

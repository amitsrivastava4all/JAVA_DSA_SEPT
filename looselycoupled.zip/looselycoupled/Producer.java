

public class Producer implements ProducerInterface{
    @Override
    public void callMe(){
        System.out.println("Producer Call Me");
        dontCallMe();
    }
    // Not expose
    public void dontCallMe(){
        System.out.println("Don't Call Me...");
    }
}

import java.util.ResourceBundle;

public class Factory {
    static ProducerInterface getInstance(){
       // ProducerInterface p = new Producer(); // Upcasting
       // Read a Property file
       ResourceBundle r = ResourceBundle.getBundle("config");
       String className = r.getString("classname");
       try{
       Object object = Class.forName(className).getDeclaredConstructor().newInstance();
       return (ProducerInterface) object; 
    }
       catch(Exception e){
        System.out.println("Wrong Class Name "+e);
       }
    //    if(className.equals("Producer")){
    //     return new Producer();
    //    }
    //    else if (className.equals("EnhanceProducer")){
    //     return new EnhanceProducer();
    //    }
    //    else
       //System.out.println(r.getString("classname"));
        //return p;
        return null;
    }
    public static void main(String[] args) {
        Factory.getInstance();
    }
}

class Person implements Cloneable{
    int id;
    String name;
    Person(){
        System.out.println("Cons call");
    }
    Person(int id, String name){
        this.id = id;
        this.name = name;
        System.out.println("Cons Call param");
    }
    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
public class CloneDemo {
    public static void main(String[] args) throws CloneNotSupportedException {
        Person person = new Person(1001 , "Ram");
        // Person person2 = person;
        // System.out.println(person.id +" "+person.name);
        // System.out.println(person2.id + " " +person2.name );
        // person.id++;
        // System.out.println(person.id +" "+person.name);
        // System.out.println(person2.id + " " +person2.name );
        // System.out.println(person == person2);
        Person person2 = (Person)person.clone();
        person2.id = 1000000;
        System.out.println(person.id +" "+person.name);
        System.out.println(person2.id + " " +person2.name );
        System.out.println(person == person2);


        

    }
}

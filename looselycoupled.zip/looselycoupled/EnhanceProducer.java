

public class EnhanceProducer implements ProducerInterface {

    @Override
    public void callMe() {
        // TODO Auto-generated method stub
        System.out.println("I am the Faster Method...");
        betterLogic();
    }

    public void betterLogic(){
        System.out.println("Better Logic...");
    }
    
}

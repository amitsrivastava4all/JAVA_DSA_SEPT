import java.io.Serializable;

class Employee implements Serializable{
    int id;
    String name;
    double salary;
    Employee(){

    }
    Employee(int id, String name, double salary){
        this.id = id;
        this.name = name;
        this.salary = salary;
    }
}
public class SerializeDeSerialize {
    public static void main(String[] args) {
        Employee e = new Employee(1001, "Ram", 9999);
        // Object File Handling
    }
}



public class Consumer {
    public static void main(String[] args) {
       // ProducerInterface pr = new Producer(); // Upcasting // Upcasting
       ProducerInterface pr = Factory.getInstance();
       pr.callMe();
       // pr.dontCallMe();
        
        
    }
}
